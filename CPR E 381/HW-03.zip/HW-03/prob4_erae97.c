#include <stdio.h>
#include <string.h>

int main(){
char key [50];
char guess [50];

	while(strcmp(key, guess != 0){
		printf("How are you?");
		scanf("%s", key);
		printf("How are you?");
		scanf("%s", guess);
	}
}	